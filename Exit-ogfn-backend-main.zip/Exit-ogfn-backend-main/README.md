# Exit-backend

features

arena lategame 

item shop works purchasing

can equip skins 


battle royale 

xp should  work now

discord bot /commands

commands down  below

additem.ts

addvbucks.ts

ban.ts

delete.ts 

fulllocker.ts

register.ts

removefullocker.ts

removeitem.ts

unban.ts
