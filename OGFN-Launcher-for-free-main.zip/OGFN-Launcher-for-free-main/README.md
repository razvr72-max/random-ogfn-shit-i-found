# Im leaking this launcher because this guy is a skid! and i may have uploaded the folder wrong but it doesnt matter anymore

# Star the repo!!

I am not gonna help you with this launcher but here is what it should look like 

# Launcher
<img width="1919" height="869" alt="image" src="https://github.com/user-attachments/assets/5b57a59e-2a7a-4100-9bb2-663d04454b26" />

# And his friend for trying to keep expose me with kovryn expose ( which isnt real making a doc on that later )

<img width="664" height="784" alt="image" src="https://github.com/user-attachments/assets/6e5c0784-f06c-47d1-ad8b-eee7180a8345" />



here are some expose pictures

# Skidding reload

<img width="638" height="184" alt="a" src="https://github.com/user-attachments/assets/741f3dcb-d229-426e-bd61-b547732185a1" />


<img width="635" height="633" alt="aa" src="https://github.com/user-attachments/assets/3c366840-60c4-4280-af5e-820472555a34" />



<img width="649" height="778" alt="aaaaaaa" src="https://github.com/user-attachments/assets/6ef34a95-77bc-4480-9ff0-b7b4d5eaa695" />

<img width="497" height="236" alt="aaaaa" src="https://github.com/user-attachments/assets/601729a5-4147-45cd-b685-33894f3eaddc" />

<img width="308" height="321" alt="aaaa" src="https://github.com/user-attachments/assets/a4329179-6b60-4192-bea0-0d45c8bae9ba" />

<img width="903" height="981" alt="aaa" src="https://github.com/user-attachments/assets/56592a0f-61f1-4c66-bb5d-384d2f383eb7" />

<img width="442" height="116" alt="aaaaaaaaaa" src="https://github.com/user-attachments/assets/e269f7da-2d00-4be5-9677-df2decb0815b" />

<img width="367" height="205" alt="image" src="https://github.com/user-attachments/assets/365c5cf1-b7c4-429b-9b63-ba7358462c44" />


# Threats

<img width="512" height="717" alt="expse" src="https://github.com/user-attachments/assets/0227be9b-8887-4b9b-8b6b-7bd54fd63799" />
