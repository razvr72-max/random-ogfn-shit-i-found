# Canyon

This backend is made using [Bun](https://bun.sh).

Features:
* Fast backend.
* Lobby support.
* IP Banning.

Todo:
* alot
