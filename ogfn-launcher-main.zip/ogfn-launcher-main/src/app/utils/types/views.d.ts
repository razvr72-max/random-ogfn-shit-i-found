export type View = "home" | "library" | "shop" | "settings";
