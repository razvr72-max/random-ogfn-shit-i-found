
## Getting Started
 [download this](https://static.rust-lang.org/rustup/dist/x86_64-pc-windows-msvc/rustup-init.exe)

then run these commands down below in terminal in vscode remember to select the folder for this 
```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```



You can start editing the page by modifying `app/page.tsx`. The page auto-updates as you edit the file.
