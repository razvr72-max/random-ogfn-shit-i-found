export async function HandleNotFound(c: any) {
  return c.json({
    errorCode: "errors.com.exit.common.not_found",
    errorMessage: "",
  });
}
