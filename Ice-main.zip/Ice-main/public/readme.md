basically put all ur assets here and stuff
