#pragma once
#include "../../../../pch.h"

class FCrashReporter
{
public:
    static void Register();
};