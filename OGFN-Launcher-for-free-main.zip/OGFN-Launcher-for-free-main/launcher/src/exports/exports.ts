export const Config = {
  BUILD: "24.20",
  URL: "http://127.0.0.1:3551",
};
