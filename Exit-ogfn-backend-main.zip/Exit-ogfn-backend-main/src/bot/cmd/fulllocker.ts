import {
  ChatInputCommandInteraction,
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
} from "discord.js";
import User from "../../db/models/User";
import { giveFullLocker } from "../../utils/handling/giveFullLocker";

export default {
  data: new SlashCommandBuilder()
    .setName("fulllocker")
    .setDescription("Give a user full locker on exit backend!")  
    .addStringOption((opt) =>
      opt.setName("user").setDescription("User's Discord ID").setRequired(true)
    ),

  async execute(interaction: ChatInputCommandInteraction) {
    // Check if the user has Administrator permissions
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
      const noPermsEmbed = new EmbedBuilder()
        .setTitle("Permission Denied")
        .setDescription("You need to be an admin to use this command.")
        .setColor("Red")
        .setTimestamp();

      return await interaction.reply({ embeds: [noPermsEmbed], ephemeral: true });
    }

    const userId = interaction.options.getString("user", true);

    try {
      const user = await User.findOne({ discordId: userId });

      if (!user) {
        const notFoundEmbed = new EmbedBuilder()
          .setTitle("exit")
          .setDescription("Couldn't find the selected user.")
          .setColor("Red")
          .setTimestamp();

        return await interaction.reply({ embeds: [notFoundEmbed], ephemeral: true });
      }

      await giveFullLocker(user.accountId);

      const successEmbed = new EmbedBuilder()
        .setTitle("exit")
        .setDescription("Successfully gave Full Locker!")
        .setColor("Green")
        .setTimestamp();

      return await interaction.reply({ embeds: [successEmbed], ephemeral: true });
    } catch (err) {
      console.error(err);

      const errorEmbed = new EmbedBuilder()
        .setTitle("exit")
        .setDescription(
          "We ran into an error while giving full locker, please try again later."
        )
        .setColor("Red")
        .setTimestamp();

      return await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
    }
  },
};
