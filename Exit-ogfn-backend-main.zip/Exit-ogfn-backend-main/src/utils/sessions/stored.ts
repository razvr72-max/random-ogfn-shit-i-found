export const gameservers: any[] = [];
export const sessions: any[] = [];
