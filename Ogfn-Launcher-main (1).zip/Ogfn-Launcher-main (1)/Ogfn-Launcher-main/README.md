# Ogfn-Launcher
This is an OGFN Launcher u can use for your project, and im open sourcing it since someone threaten to leak it

# Threats????

<img width="1544" height="1003" alt="image" src="https://github.com/user-attachments/assets/a177e4cd-fc42-4fb7-a7ac-434b23fafac1" />

## Claiming that im selling other people project launchers!!

<img width="1523" height="803" alt="image" src="https://github.com/user-attachments/assets/8028e84b-ceaf-47a6-8b22-a3f0b50d5def" />
