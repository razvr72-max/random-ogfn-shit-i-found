import { WebSocket } from "ws";
import jwt from "jsonwebtoken";
import { Connecting } from "../states/connecting";
import Matchmaking from "../../../db/models/Matchmaking";
import { gameservers, sessions } from "../../sessions/sessions";
import { Waiting } from "../states/waiting";
import { Queued } from "../states/queued";

export async function handleStates(ws: WebSocket, req: any) {
  const status: any = ws;
  let data: any;
  let queueLoop: any;
  var hs = (req.headers.authorization || "").split(" ");
  function sendMessage(socket: any, type: any, payload: any) {
    socket.send(
      JSON.stringify({
        payload: payload,
        name: type,
      })
    );
  }

  try {
    data = jwt.verify(hs[2] + "." + hs[3], "23tsxgdfxu563wawrasgd");
  } catch {
    sendMessage(ws, "Error", {
      error: "Error Communicating With Matchmaker",
    });
    ws.close(1000);
    return;
  }

  if (
    !req.headers.authorization ||
    hs[0] != "Epic-Signed" ||
    hs[1] != "exit"
  ) {
    sendMessage(ws, "Error", {
      error: "Error Communicating With Matchmaker",
    });
    ws.close(1000);
    return;
  }

  Connecting(status);
  await new Promise((resolve) => setTimeout(resolve, 800));
  Waiting(status);
  await new Promise((resolve) => setTimeout(resolve, 1000));
  Queued(status);

  queueLoop = setInterval(async () => {
    let gs;
    if (
      (gs = gameservers.find(
        (f: any) =>
          f.key == false &&
          f.playlist.toLowerCase() == data.playlist.toLowerCase() &&
          f.region.toLowerCase() == data.region.toLowerCase()
      ))
    ) {
      clearInterval(queueLoop);
      sendMessage(ws, "StatusUpdate", {
        matchId: gs.id,
        state: "SessionAssignment",
      });

      let sessionId = gs.id;
      const matchmaking = (await Matchmaking.findOne({
        accountId: data.accountId,
      })) as any;
      if (matchmaking) {
        matchmaking.sessionId = sessionId;
        await matchmaking.save();
        sessions.push({
          sessionId,
          matchId: gs.id,
        });

        sendMessage(ws, "Play", {
          matchId: gs.id,
          sessionId: sessionId,
          joinDelaySec: 0,
        });
      }

      ws.close(1000);
    }
  }, 10);
}
