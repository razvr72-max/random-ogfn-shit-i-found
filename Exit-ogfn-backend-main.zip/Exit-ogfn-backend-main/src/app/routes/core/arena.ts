import app from "../../..";
import User from "../../../db/models/User";
import Profiles from "../../../db/models/Profiles";
import Tournaments from "../../../db/models/Tournaments";

export default function () {
  app.get("/sessions/api/v1/hype/:username/:reason", async (c) => {
    const user = await User.findOne({ username: c.req.param("username") });
    if (!user) return c.text("User not found!");

    const tournaments = await Tournaments.findOne({ 
      accountId: user.accountId,
    });
    if (!tournaments) return c.text("User not found!");

    const reason = c.req.param("reason");
    switch (reason) {
      case "Kill":
        tournaments.hype += 15;
        break;
      case "Top5":
        tournaments.hype += 10;
        break;
      case "Top10":
        tournaments.hype += 5;
        break;
    }

    const hype = tournaments.hype;

    const hypeAmounts = [
      400, 800, 1500, 2000, 3500, 4500, 7500, 9000, 12000, 20000,
    ] as const;

    let division = 0;
    for (let i = 0; i < hypeAmounts.length; i++) {
      const amount = hypeAmounts[i];
      if (amount !== undefined && hype >= amount) {
        division = i + 1;
      }
    }

    tournaments.divisions = tournaments.divisions || [];
    for (let i = 1; i <= division; i++) {
      const divisionType = `NormalArenaDiv${i}`;
      if (!tournaments.divisions.includes(divisionType)) {
        tournaments.divisions.push(divisionType);
      }
    }

    await tournaments.save();
    return c.text("Success");
  });
}
