b4 doing anything

bun install

then for testing
bun tauri dev

for building to public
bun tauri build

go to src-tauri/target/release/bundle/msi and you should find the installer there!!!@
