# i dont plan on continuing this, you will NOT have a good experience with this backend.

Please give credits, if you skid this I will find you.

- [ ] Challenges
- [ ] Lobby
- [ ] Battle Pass
- [X] News for Chapter 2+
- [ ] Arena
- [X] Anti-Exploit
- [X] Auto Rotate
- [ ] 1:1 experience
- [X] Good logging system
- [X] IP Bans
- [X] Anti-skid 🤫

And please leave my credits in Emergency Notices or at least in the news tab.

Credits:

[nade](https://github.com/gn1e) - For being the main developer on this backend.

[pixelstrap](https://github.com/pxlstrap) - For also developing the backend.

[FortniteEndpointsDocumentation](https://github.com/LeleDerGrasshalmi/FortniteEndpointsDocumentation) - For documenting alot of endpoints and their responses.
