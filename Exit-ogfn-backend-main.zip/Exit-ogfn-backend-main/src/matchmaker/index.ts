import app from "..";
import { WebSocketServer, WebSocket } from "ws";
import { handleStates } from "./utils/handlers/message";
import { v4 as uuid } from "uuid";
import { Log } from "../utils/handling/logging";
import { gameservers, sessions } from "./sessions/sessions";

const server = new WebSocketServer({ port: 85 });
Bun.serve({
  port: 81,
  fetch: app.fetch,
});

app.use(async (c, next) => {
  Log(`${c.req.path} | ${c.req.method}`);
  await next();
});

server.on(
  "connection",
  (ws: WebSocket & { dispatchEvent: (event: Event) => boolean }, req) => {
    handleStates(ws, req);
  }
);

Log(`Matchmaker Running on Port 85 `);
Log("Matchmaker HTTP Running on Port 81 ");

app.get("/exit/v1/session/:sessionId", async (c) => {
  var sessionIndex = sessions.findIndex(
    (s: any) => s.sessionId == c.req.param("sessionId")
  );
  if (sessionIndex == -1) return c.json([], 404);
  var gsi = gameservers.findIndex(
    (g: any) => g.id == sessions[sessionIndex].matchId
  );
  if (gsi == -1) return c.json([], 404);
  sessions.splice(sessionIndex, 1);
  return c.json({
    ip: gameservers[gsi].ip,
    port: gameservers[gsi].port,
  });
});

app.post("/exit/v1/gs/create", async (c) => {
  const body: any = await c.req.json();
  if (!body.region || !body.ip || !body.port || !body.playlist)
    return c.json([], 400);

  var gsIndex = gameservers.findIndex(
    (gs: any) =>
      gs.region == body.region &&
      gs.ip == body.ip &&
      gs.port == body.port &&
      gs.playlist == body.playlist
  );

  if (gsIndex == -1) {
    gameservers.push({
      region: body.region,
      ip: body.ip,
      port: body.port,
      playlist: body.playlist,
      id: uuid().replace(/-/g, ""),
      key: false,
    });
  }

  return c.json([], 201);
});

app.post("/exit/v1/gs/delete", async (c) => {
  const body: any = await c.req.json();
  if (!body.region || !body.ip || !body.port) return c.json([], 400);

  var gsIndex;
  while (
    (gsIndex = gameservers.findIndex(
      (gs: any) =>
        gs.region == body.region &&
        gs.ip == body.ip &&
        gs.port == body.port &&
        gs.key == false
    )) != -1
  ) {
    gameservers.splice(gsIndex, 1);
  }

  return c.json([], 200);
});
