export let gameservers: any = [];
export let sessions: any = [];
